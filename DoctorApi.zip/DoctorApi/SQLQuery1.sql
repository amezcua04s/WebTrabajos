﻿SELECT * FROM Doctores 
INSERT INTO Doctores (nombre,especialidad,correo, telefono) 
VALUES ('Gerardo Cornejo', 'Cardiologia','geracor994@gmail.com', '5467890390'),
('Alfonso Monroy', 'Neurolog�a','alfonsito@gmail.com', '7689765674'),
('Luis Miguel', 'Pediatria', 'Luismi@gmail.com', '9890987865'),
('Cristiano Ronaldo', 'Ginecologia', 'Crisjr@gmail.com', '7689098713'), 
('Miguel Torres', 'Cardiologia', 'myketowers@gmail.com', '7658907632')

SELECT * FROM Doctores