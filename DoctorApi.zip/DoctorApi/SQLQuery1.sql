﻿SELECT * FROM Doctores 
INSERT INTO Doctores (nombre,especialidad,correo, telefono) 
VALUES ('Kenia Os', 'Dermatología','kenini@gmail.com', '5467890390'),
('Alfonso Monroy', 'Neurología','almon@gmail.com', '7689765674'),
('Daniela reyes', 'Pediatria', 'darey@gmail.com', '9890987865'),
('Alfredon Uzeta', 'Ginecologia', 'alfuz@gmail.com', '7689098713'), 
('José Jimenez', 'Cardiologia', 'jojim@gmail.com', '7658907632')

SELECT * FROM Doctores